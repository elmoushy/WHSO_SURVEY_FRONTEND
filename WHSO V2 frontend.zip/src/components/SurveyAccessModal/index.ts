export { default } from './SurveyAccessModal.vue'
