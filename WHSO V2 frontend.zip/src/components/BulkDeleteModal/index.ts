export { default } from './BulkDeleteModal.vue'
