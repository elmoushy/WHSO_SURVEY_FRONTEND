export { default } from './TemplateGalleryModal.vue'
