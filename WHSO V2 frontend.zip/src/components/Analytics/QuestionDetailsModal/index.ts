export { default } from './QuestionDetailsModal.vue'
