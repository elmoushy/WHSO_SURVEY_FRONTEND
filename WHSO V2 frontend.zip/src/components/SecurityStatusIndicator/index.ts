export { default } from './SecurityStatusIndicator.vue'
