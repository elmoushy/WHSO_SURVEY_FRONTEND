export { default } from './ResetPasswordModal.vue'
