export { default } from './Notifications.vue'
